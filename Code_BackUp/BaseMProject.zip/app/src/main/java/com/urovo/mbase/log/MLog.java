package com.urovo.mbase.log;

import android.text.TextUtils;
import android.util.Log;

import com.urovo.mbase.BaseApplication;


public class MLog {
    public static void e(String msg) {
        if (!TextUtils.isEmpty(msg)) {
            int start = 0;
            int len = 3 * 1024;
            while (msg.length() - start > len) {
                Log.e("log", ">>" + msg.substring(start, start += len));
            }
            Log.e("log", ">>" + msg.substring(start));
        } else {
            Log.e("log", ">>" + msg);
        }
    }

    public static void d(String msg) {
//        Log.d("log", ">>" + msg);
        //
        printLog(MLog.class, ">>" + msg);
    }

    public static <T> void printLog(Class<T> cla, String message) {
        BaseApplication.getLog(cla).debug(message);
    }

    public static <T> void printErrLog(Class<T> cla, String message) {
        BaseApplication.getLog(cla).error(message);
    }

}

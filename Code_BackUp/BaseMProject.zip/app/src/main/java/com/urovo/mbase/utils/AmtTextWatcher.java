package com.urovo.mbase.utils;

import android.text.Editable;
import android.text.TextWatcher;

public class AmtTextWatcher implements TextWatcher {

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
                                  int after) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        // TODO Auto-generated method stub

    }

    @Override
    public void afterTextChanged(Editable s) {
        // TODO Auto-generated method stub

        // TODO Auto-generated method stub
        if (s != null && s.length() != 0) {
            if (String.valueOf(s.charAt(0)).equals(".")) {
                s.clear();
                return;
            }
            if (String.valueOf(s.charAt(0)).equals("0")) {
                if (s.length() > 1 && !String.valueOf(s.charAt(1)).equals(".")) {
                    s.delete(0, 1);
                    return;
                }
            }
            if (s.toString().contains(".")) {
                int index = s.toString().indexOf(".");
                int last = s.toString().lastIndexOf(".");
                if (index != last) {
                    s.delete(s.length() - 1, s.length());
                } else if (s.length() > index + 3)// 保留两位小数
                {
                    s.delete(index + 3, s.length());
                }
            }
        }
    }

}

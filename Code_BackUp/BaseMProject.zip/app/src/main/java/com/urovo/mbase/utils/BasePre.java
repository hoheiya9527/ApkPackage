package com.urovo.mbase.utils;

import com.tencent.mmkv.MMKV;

import java.net.URLEncoder;

public class BasePre {

    private static MMKV mmkv;

    public static MMKV initMMKV() {
        if (mmkv == null) {
            mmkv = MMKV.defaultMMKV();
        }
        return mmkv;
    }

    public static boolean saveInt(String key, int value) {
        return initMMKV().encode(key, value);
    }

    public static boolean saveBoolean(String key, boolean value) {
        return initMMKV().encode(key, value);
    }

    public static boolean saveString(String key, String value) {
        return initMMKV().encode(key, value);
    }

    public static int getInt(String key, int defaultValue) {
        return initMMKV().decodeInt(key, defaultValue);
    }

    public static boolean getBoolean(String key, boolean defaultValue) {
        return initMMKV().decodeBool(key, defaultValue);
    }

    public static String getString(String key, String defaultValue) {
        return initMMKV().decodeString(key, defaultValue);
    }

    public static boolean saveFloat(String key, float value) {
        return initMMKV().encode(key, value);
    }

    public static float getFloat(String key, float defaultValue) {
        return initMMKV().decodeFloat(key, defaultValue);
    }

    public static boolean isOpen(String key) {
        return initMMKV().decodeBool(key, false);
    }

    public static boolean setOpen(String key, boolean value) {
        return initMMKV().encode(key, value);
    }


}

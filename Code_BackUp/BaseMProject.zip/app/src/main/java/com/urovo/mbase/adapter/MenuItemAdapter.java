package com.urovo.mbase.adapter;

import androidx.annotation.NonNull;

import com.urovo.mbase.R;
import com.urovo.mbase.model.MenuInfo;
import com.xuexiang.xui.adapter.recyclerview.BaseRecyclerAdapter;
import com.xuexiang.xui.adapter.recyclerview.RecyclerViewHolder;

import java.util.List;

public class MenuItemAdapter extends BaseRecyclerAdapter<MenuInfo> {

    public MenuItemAdapter(List<MenuInfo> list) {
        super(list);
    }

    @Override
    public int getItemLayoutId(int viewType) {
        return R.layout.layout_item_menu;
    }

    @Override
    public void bindData(@NonNull RecyclerViewHolder holder, int position, MenuInfo item) {
        holder.text(R.id.item_name, item.getContent());
        if (item.getIcon() != 0) {
            holder.image(R.id.item_icon, item.getIcon());
        }
    }

}

package com.urovo.mbase.utils;

import android.text.TextUtils;

import com.urovo.mbase.model.DataInfo;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Pattern;

public class StringUtil {
    public static DecimalFormat amountFormat = new DecimalFormat(
            "000000000000");// 12位
    public static DecimalFormat amount2Format = new DecimalFormat("0.00");

    /**
     * 判断字符串是否为null或""
     *
     * @param str
     * @return
     */
    public static boolean isEmpty(String str) {
        return TextUtils.isEmpty(str);
    }

    /**
     * 判断字符串是否不为null或""
     *
     * @param str
     * @return
     */

    public static boolean notEmpty(String str) {
        return !TextUtils.isEmpty(str);
    }

    /**
     * 金额表示方式转换，如0.01转为0000 0000 0001
     *
     * @param amount
     * @return
     */
    public static String get12Amount(String amount) {
        // TODO Auto-generated method stub
        double parseDouble = Double.parseDouble(amount);
        return amountFormat.format(parseDouble * 100);
    }

    public static String get12Amount(Double amount) {
        // TODO Auto-generated method stub
        return amountFormat.format(amount * 100);
    }

    /**
     * 金额表示方式转换，如0000 0000 0001转为0.01
     *
     * @param amount
     * @return
     */
    public static String getTwoPointAmount(String amount) {
        // TODO Auto-generated method stub
        if (TextUtils.isEmpty(amount)) {
            return "";
        }
        try {
            BigDecimal bigDecimal = new BigDecimal(amount);
            BigDecimal divide = bigDecimal.divide(new BigDecimal("100"),2,BigDecimal.ROUND_HALF_UP);
            BigDecimal decimal = divide.setScale(2, BigDecimal.ROUND_HALF_UP);
            return decimal.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String getTwoPointAmount(long amount) {
        // TODO Auto-generated method stub
        try {
            return amount2Format.format(amount * 1.0 / 100);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String formatAmount(Double amount) {
        // TODO Auto-generated method stub
        return amount2Format.format(amount);
    }

    /**
     * 左对齐，右补空格
     *
     * @param string
     * @param length
     * @return
     */
    public static String leftAlignByblank(String string, int length) {
        return leftAlignBy(string, length, " ");
    }

    public static String leftAlignBy(String string, int length, String chart) {
        if (isEmpty(string) || string.length() >= length) {
            return string;
        }
        StringBuilder builder = new StringBuilder();
        builder.append(string);
        for (int i = 0; i < length - string.length(); i++) {
            builder.append(chart);
        }
        return builder.toString();
    }

    /**
     * 右对齐，左补空格
     *
     * @param string
     * @param length
     * @return
     */
    public static String rightAlignByblank(String string, int length) {
        return rightAlignBy(string, length, " ");
    }

    public static String rightAlignBy(String string, int length, String chart) {

        if (isEmpty(string) || string.length() >= length) {
            return string;
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < length - string.length(); i++) {
            builder.append(chart);
        }
        builder.append(string);
        return builder.toString();
    }

    public static String formatNum(int number, String decimalFormat) {
        return new DecimalFormat(decimalFormat).format(number);
    }

    public static String reEmpty(String string) {
        // TODO Auto-generated method stub
        return isEmpty(string) ? "" : string;
    }

    /**
     * 如果为空，填全0
     *
     * @param string
     * @param length 长度
     * @return
     */
    public static String reZero(String string, int length) {
        // TODO Auto-generated method stub
        if (isEmpty(string)) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < length; i++) {
                builder.append("0");
            }
            return builder.toString();
        }
        return string;
    }


    public static String encryPan(String pan) {
        // TODO Auto-generated method stub
        if (StringUtil.isEmpty(pan)) {
            pan = "";// 18位付款码
        }
        if (pan.contains("*") || pan.length() < 10) {
            return pan;
        }
        StringBuffer buffer = new StringBuffer();
        buffer.append(pan.substring(0, 6));
        String string = pan.substring(6, pan.length() - 4);
        for (int i = 0; i < string.length(); i++) {
            buffer.append("*");
        }
        buffer.append(pan.substring(pan.length() - 4, pan.length()));
        return buffer.toString();
    }

    public static boolean isNumeric(String string) {
        if (TextUtils.isEmpty(string)) {
            return false;
        }
        Pattern pattern = Pattern.compile("[0-9]*");
        return pattern.matcher(string).matches();
    }
}

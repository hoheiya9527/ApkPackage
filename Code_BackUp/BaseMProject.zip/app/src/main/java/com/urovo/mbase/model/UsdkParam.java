package com.urovo.mbase.model;

public class UsdkParam {
    private String IS_ORDER_REVERSE;//订单冲正
    private String IS_SUP_ORDER_PAYMENY;//订单支付

    public UsdkParam() {
    }

    public UsdkParam(boolean isOpen) {
        super();
        this.IS_ORDER_REVERSE = isOpen ? "1" : "0";
        this.IS_SUP_ORDER_PAYMENY = "1";
    }

    public String getIS_ORDER_REVERSE() {
        return IS_ORDER_REVERSE;
    }

    public void setIS_ORDER_REVERSE(String IS_ORDER_REVERSE) {
        this.IS_ORDER_REVERSE = IS_ORDER_REVERSE;
    }

    public String getIS_SUP_ORDER_PAYMENY() {
        return IS_SUP_ORDER_PAYMENY;
    }

    public void setIS_SUP_ORDER_PAYMENY(String IS_SUP_ORDER_PAYMENY) {
        this.IS_SUP_ORDER_PAYMENY = IS_SUP_ORDER_PAYMENY;
    }
}

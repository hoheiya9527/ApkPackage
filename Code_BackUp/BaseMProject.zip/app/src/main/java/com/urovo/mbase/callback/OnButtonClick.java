package com.urovo.mbase.callback;

public interface OnButtonClick {
    void onClick();
}

package com.urovo.mbase;

import android.os.Environment;
import android.view.Gravity;

import com.tencent.mmkv.MMKV;
import com.xuexiang.xhttp2.XHttpSDK;
import com.xuexiang.xui.widget.toast.XToast;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.litepal.LitePalApplication;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Executors;

import de.mindpipe.android.logging.log4j.LogConfigurator;


public class BaseApplication extends LitePalApplication {

    private static BaseApplication instance;

    public static BaseApplication getInstance() {
        return instance;
    }

    public static String directoryName;

    private String logName;

    private static String oper;

    public static <T> Logger getLog(Class<T> cla) {
        return Logger.getLogger(cla);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        //Toast行为配置
        XToast.Config.get().allowQueue(false);
        XToast.Config.get().setGravity(Gravity.CENTER);
        //
        XHttpSDK.init(this);   //初始化网络请求框架，必须首先执行
//        XHttpSDK.debug("XHttp");  //需要调试的时候执行
        MMKV.initialize(this);
    }

    public void init() {
        directoryName = getLogDirectory();
        logName = new SimpleDateFormat("yyyyMMdd", Locale.CHINA).format(new Date()) + ".txt";
        configLog(directoryName + File.separator + logName);
        deleteLog(50, 100);
    }

    public String getLogDirectory() {
        return Environment.getExternalStorageDirectory()
                + File.separator
                + getPackageName()
                + File.separator
                + "log";
    }


    private void configLog(String path) {
        try {
            final LogConfigurator logConfigurator = new LogConfigurator();
            logConfigurator.setFileName(path);
            logConfigurator.setRootLevel(Level.ALL);
            logConfigurator.setLevel("org.apache", Level.ALL);
            logConfigurator.setFilePattern("%d %-5p [%c{2}] %m%n%n");
            logConfigurator.setMaxFileSize(1024 * 1024 * 5);
            logConfigurator.setImmediateFlush(true);
            // logConfigurator.setUseLogCatAppender(false);
            logConfigurator.configure();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 当日志文件数量超过outDays个，删除days个之前的
     *
     * @param days    保留N天前的日志
     * @param outDays 日志数量达到该数量时作删除操作
     */
    public void deleteLog(int days, int outDays) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                File file = new File(directoryName);
                File[] listFiles = file.listFiles();
                if (listFiles.length >= outDays && listFiles.length > days) {
                    for (int i = 0; i < listFiles.length - days; i++) {
                        // Log.e("test", ">>>" + listFiles[i].getName());
                        listFiles[i].delete();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

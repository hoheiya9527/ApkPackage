package com.urovo.mbase.adapter;

import androidx.annotation.NonNull;

import com.urovo.mbase.R;
import com.urovo.mbase.model.DataInfo;
import com.xuexiang.xui.adapter.recyclerview.BaseRecyclerAdapter;
import com.xuexiang.xui.adapter.recyclerview.RecyclerViewHolder;

import java.util.List;

public class InfoAdapter extends BaseRecyclerAdapter<DataInfo> {

    public InfoAdapter(List<DataInfo> list) {
        super(list);
    }

    @Override
    public int getItemLayoutId(int viewType) {
        return R.layout.layout_item_info;
    }

    @Override
    public void bindData(@NonNull RecyclerViewHolder holder, int position, DataInfo item) {
        holder.text(R.id.item_name, item.getName());
        holder.text(R.id.item_value, item.getValue());
    }

}

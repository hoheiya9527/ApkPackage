package com.urovo.mbase.model;

public class MenuInfo {
    private int type;
    private int icon;
    private String content;

    public MenuInfo(int type, int icon, String content) {
        this.type = type;
        this.icon = icon;
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

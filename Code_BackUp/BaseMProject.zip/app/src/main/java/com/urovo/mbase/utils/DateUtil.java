package com.urovo.mbase.utils;

import android.text.TextUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtil {
    private static SimpleDateFormat dateFormat = new SimpleDateFormat(
            "yyyy/MM/dd HH:mm:ss", Locale.CHINA);
    private static SimpleDateFormat formatDate = new SimpleDateFormat(
            "yyyy/MM/dd", Locale.CHINA);
    private static SimpleDateFormat dateFormat1 = new SimpleDateFormat(
            "yyyyMMddHHmmss", Locale.CHINA);

    /**
     * yyyy/MM/dd HH:mm:ss
     */
    public static String getDateTime() {
        // TODO Auto-generated method stub
        return dateFormat.format(new Date());
    }

    /**
     * @return yyyyMMddHHmmss
     */
    public static String getyMdHms() {
        return formatBy(new Date(), "yyyyMMddHHmmss");
    }

    /**
     * @return yyyyMMddHHmmss
     */
    public static String getyMdHms(Date date) {
        return formatBy(date, "yyyyMMddHHmmss");
    }

    /**
     * 按指定格式获取时间
     *
     * @param date
     * @param format
     * @return
     */
    public static String formatBy(Date date, String format) {
        return new SimpleDateFormat(format, Locale.CHINA).format(date);
    }

    /**
     * 12域时间
     *
     * @return
     */
    public static String getTime() {
        return formatBy(new Date(), "HHmmss");
    }

    /**
     * 13域日期
     *
     * @return
     */
    public static String getDate() {
        return formatBy(new Date(), "MMdd");
    }

    public static String getDate(Date date) {
        return formatBy(date, "MMdd");
    }

    /**
     * 指定时间值用于判断当前系统时间是否有效
     *
     * @param time yyyy/MM/dd HH:mm:ss
     * @return
     */
    public static boolean dateIsValid(String time) {
        try {
            Date now = new Date();
            Date timeDate = dateFormat.parse(time);
            return now.after(timeDate);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return true;// 默认有效
    }

    /**
     * 获取年份
     *
     * @return
     */
    public static String getYear() {
        return formatBy(new Date(), "yyyy");
    }

    /**
     * 距离指定时间相差i天的日期集合，含当天
     *
     * @param startTime yyyy/MM/dd hh:mm:ss
     * @param i         正：该时间之后的天数，负：之前的天数
     * @return
     */
    public static ArrayList<String> calDays(String startTime, int i) {
        // TODO Auto-generated method stub
        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            Date now = dateFormat.parse(startTime);
            Calendar cal = Calendar.getInstance(Locale.CHINA);
            cal.setTime(now);
            arrayList.add(formatDate.format(cal.getTime()));// 含当天
            if (i > 0)// 正数，取之后的日期
            {
                for (int j = 0; j < i; j++) {
                    cal.add(Calendar.DATE, 1);
                    arrayList.add(formatDate.format(cal.getTime()));
                }
            } else// 负数，取之前的日期，包含当天
            {
                for (int j = i; j < 0; j++) {
                    cal.add(Calendar.DATE, -1);
                    arrayList.add(formatDate.format(cal.getTime()));
                }
            }
            return arrayList;
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return arrayList;
    }

    /**
     * 计算两个日期之间的间隔天数
     *
     * @param startTime yyyy/MM/dd hh:mm:ss
     * @param endTime
     * @return 间隔天数，-1：发生异常
     */
    public static int calDays(String startTime, String endTime) {
        // TODO Auto-generated method stub
        try {
            Date start = dateFormat.parse(startTime);
            Date end = dateFormat.parse(endTime);
            return (int) ((end.getTime() - start.getTime())
                    / (24 * 60 * 60 * 1000)) + 1;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return -1;
    }

    public static String getDate(String date, String sourceFormat,
                                 String targetFormat) {
        if (TextUtils.isEmpty(date)) {
            return "";
        }
        try {
            Date parse = new SimpleDateFormat(sourceFormat).parse(date);
            return formatBy(parse, targetFormat);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    /**
     * @param date
     * @param time
     * @return
     */
    public static String getDateTime(String date, String time) {
        try {
            StringBuilder builder = new StringBuilder();
            //yyyy/
            builder.append(getYear())
                    .append("/");
            //MM/dd
            builder.append(date.substring(0, 2))
                    .append("/")
                    .append(date.substring(2, 4));
            // HH:mm:ss
            builder.append(" ")
                    .append(time.substring(0, 2))
                    .append(":")
                    .append(time.substring(2, 4))
                    .append(":")
                    .append(time.substring(4, 6));
            return builder.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return getDateTime();
        }
    }


    /**
     * @return yyyyMMddHHmmss
     */
    public static String getDateTimeLine() {
        // TODO Auto-generated method stub
        return dateFormat1.format(new Date());
    }

    /**
     * @return yyyy/MM/dd
     */
    public static String getymdXg() {
        return new SimpleDateFormat("yyyy/MM/dd", Locale.CHINA).format(new Date());
    }

    /**
     * @return yyyy-MM-dd HH:mm:ss
     */
    public static String getY_M_d_H_m_s() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
    }

    public static String getymd() {
        return new SimpleDateFormat("yyyyMMdd", Locale.CHINA).format(new Date());
    }

    public static String getHms() {
        return new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date());
    }
}

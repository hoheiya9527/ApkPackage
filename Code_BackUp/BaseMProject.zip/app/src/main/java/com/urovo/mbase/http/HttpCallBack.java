package com.urovo.mbase.http;

import com.urovo.mbase.log.MLog;
import com.xuexiang.xhttp2.callback.CallBack;
import com.xuexiang.xhttp2.exception.ApiException;

public abstract class HttpCallBack<String> extends CallBack<String> {
    @Override
    public void onStart() {
        MLog.d("HttpCallBack.onStart");
    }

    @Override
    public void onSuccess(String result) throws Throwable {
        MLog.d("HttpCallBack.onSuccess:" + result);
    }

    @Override
    public void onError(ApiException e) {
        MLog.d("HttpCallBack.onError: \n[getCode:" + e.getCode() + ",\ngetMessage:" + e.getMessage() + ",\ngetDetailMessage:" + e.getDetailMessage() + "]");
    }

    @Override
    public void onCompleted() {
        MLog.d("HttpCallBack.onCompleted");
    }
}

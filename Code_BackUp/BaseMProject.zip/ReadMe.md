*************************
#Project说明：
    BaseMProject为自封装library，提供外部引入的方式，用于统一规范并快速方便集成。
    
#基本功能：
    1、UI：使用XUI界面框架，提供默认UI元素如button等，详见https://github.com/xuexiangjys/XUI/wiki
    2、数据库：使用LitePal数据库框架。
    3、异步：使用RXJAVA框架。
    4、网络请求：使用XHttp2框架。
    5、权限请求：使用EasyPermisson框架。
    6、数据持久化：使用MMKV工具。
    
*************************
**************
##一、project引入步骤
   ###1、创建项目APP，将BaseMProject与项目APP并列在同一目录，编辑项目APP的settings.gradle添加以下内容：
    //------------引入library----------
    include ':BaseMProject'
    project (':BaseMProject').projectDir = new File('../BaseMProject/')
    include ':BaseMProject:app'
    //---------------------------------
 
   ###2、在项目APP的外层build.gradle添加maven仓库，如下
    //------------添加maven----------
    allprojects {
       repositories {
           google()
           jcenter()
           maven { url "https://jitpack.io" }
       }
    }
    
   ###3、在项目APP的内层build.gradle进行moudle引用
    dependencies {
        //引用library
        implementation project(path: ':BaseMProject:app')
    }
    
  
**************
**************
##二、操作说明
   ###1、 初始化应用
   （1）分别继承BaseApplication、BaseActivity
   （2）manifest文件声明引入application
   
   ###2、数据操作
   （1）SQLite：创建数据库模型类，新建litepal.xml于assets目录（具体操作参考litepal用法）。
   （2）MMKV：可直接继承BasePre，再定义函数进行key-value操作。
   
   ###3、权限申请
   （1）manifest进行权限声明，应用入口activity
   复写getPerms()、overPermission()函数，并在initView函数进行requiresPermission方法调用。
   
   ###4、日志输出
   （1）只作logcat输出使用MLog.d()
   （2）作文件输出使用MLog.print()
   （3）可在application复写getLogDirectory修改日志文件路径
   
   ###5、网络请求
   （1）GET请求
   
        try {
            new GetRequest(url + "?key=value")
                .baseUrl(url.substring(0, url.lastIndexOf("/") + 1))
                //.syncRequest(true)//同步请求
                .keepJson(true)//不自动解析
                .onMainThread(true)//收到响应后回到主线程
                .execute(httpCallBack);
        } catch (Exception e) {
                e.printStackTrace();
                httpCallBack.onError(new ApiException(e.getMessage(), -99));
        }
              
   （2）POST请求
   
        try {
                new PostRequest(url)
                        .baseUrl(url.substring(0, url.lastIndexOf("/") + 1))
                        //.timeOut()//超时时间
                        //.syncRequest(true)//同步请求
                        //.upJson("")//上传json格式数据
                        .upString("")//上传字符串数据
                        .headers("Accept", "*/*")
                        .headers("Content-Type", "application/json")//请求头
                        .hostnameVerifier((s, sslSession) -> true)
                        .certificates()//信任所有证书
                        .keepJson(true)//不自动解析
                        .onMainThread(true)//收到响应后回到主线程
                        .execute(httpCallBack);
            } catch (Exception e) {
                e.printStackTrace();
                httpCallBack.onError(new ApiException(e.getMessage(), -99));
            }
   
   （3）其他用法详见https://github.com/xuexiangjys/XHttp2/wiki
                
   ###6、UI元素
   （1）优先引用style中已定义样式，再者可参考XUI自带样式，不能满足再自行定义创建。
   
   （2）titlebar引入
        <include layout="@layout/titlebar" />
        
   （3）RecyclerView快速配置
        1.adapter继承BaseRecyclerAdapter<T>
        2.处理布局使用WidgetUtils.initGridRecyclerView(mRecyclerView, 2);
        3.数据初始并setAdapter，完成。
        4.如需进行item点击事件监听，使用adapter的setOnItemClickListener即可。
        
   （4）    
    
   
**************